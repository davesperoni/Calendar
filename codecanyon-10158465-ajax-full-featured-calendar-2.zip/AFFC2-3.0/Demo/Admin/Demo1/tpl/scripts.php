<script src="lib/moment.js"></script>
<script src="lib/jquery.js"></script>
<script src="lib/jquery-ui.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/fullcalendar.js"></script>
<script src="js/lang-all.js"></script>
<script src="js/jquery.calendar.js"></script>
<script src="lib/spectrum/spectrum.js"></script>

<script src="lib/timepicker/jquery-ui-sliderAccess.js"></script>
<script src="lib/timepicker/jquery-ui-timepicker-addon.min.js"></script>

<script src="js/custom.js"></script>

<script src="js/g.map.js"></script>
<script src="http://maps.google.com/maps/api/js" defer></script>