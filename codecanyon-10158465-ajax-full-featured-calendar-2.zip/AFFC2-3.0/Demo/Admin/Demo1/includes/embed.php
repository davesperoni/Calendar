<?php
	/*
	* PHP Embed Class
	* This will just embed Video, Images, Audio according to the providers
	* Paulo Regina - 2016
	* Version: 1.5
	*/
	class EmbedEmbed
	{
		// Providers keys must match Rules Keys
		
		// The Regex to find embed code of providers
		public $providers_regex = array(
			
			// video
			"dailymotion.com/video/" => "/DM_CurrentVideoXID='(.*?)';/",
			"youtube.com/watch"      => '/"video_id":"(.*?)"/',
			"youtu.be"               => '/"video_id":"(.*?)"/',
			"maker.tv"                => '/"content_ids":\["(.*?)"\]/',
			"vimeo.com"              => '/"clip":{"id":(.*?),/',
			"metacafe.com/watch/"    => '/content="http:\/\/www.metacafe.com\/watch\/(.*?)"/',
			"funnyordie.com/videos/" => '/video id="videoPlayer-(.*?)"/',
			
			// Audio
			"soundcloud.com/"        => '/&lt;!\[CDATA\[(.*?)\]\]&gt;</',
			"official.fm/"           => '/&quot;track_id&quot;:&quot;(.*?)&quot;,/',
			
			// Rich
			"slideshare.net"         => '/embed_code\/key\/(.*?)","/'
		);
		
		// The Embed Rules provided by the providers
		private $rules = array(
		
			// video 
			'dailymotion.com/video/' => '<iframe frameborder="0" width="100%" height="270" src="http://www.dailymotion.com/embed/video/%embedCode%" allowfullscreen></iframe>',
			'youtube.com/watch'      => '<iframe width="100%" height="315" src="https://www.youtube.com/embed/%embedCode%" frameborder="0" allowfullscreen></iframe>',
			'youtu.be'               => '<iframe width="100%" height="315" src="https://www.youtube.com/embed/%embedCode%" frameborder="0" allowfullscreen></iframe>',
			'maker.tv'                => '<iframe width="100%" height="315" src="http://makerplayer.com/embed/maker/%embedCode%" frameborder="0" allowfullscreen seamless scrolling="no"></iframe>',
			'vimeo.com'              => '<iframe src="https://player.vimeo.com/video/%embedCode%" width="100%" height="281" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>',
			'metacafe.com/watch/'    => '<iframe src="http://www.metacafe.com/embed/%embedCode%" width="100%" height="248" allowFullScreen frameborder=0></iframe>',
			'funnyordie.com/videos/' => '<iframe src="http://www.funnyordie.com/embed/%embedCode%" width="100%" height="400" frameborder="0" allowfullscreen webkitallowfullscreen mozallowfullscreen></iframe>',
			
			// Audio
			"soundcloud.com/"        => '%embedCode%',
			"official.fm/"           => '<iframe width="100%" height="400" frameborder="no" src="http://www.official.fm/player?width=auto&height=400&aspect=flat&feed=http%3A%2F%2Fwww.official.fm%2Ffeed%2Ftracks%2F%embedCode%.json"></iframe>',
			
			// Rich
			"slideshare.net"         => '<iframe src="//www.slideshare.net/slideshow/embed_code/key/%embedCode%" width="100%" height="485" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" style="border:1px solid #CCC; border-width:1px 1px 0; margin-bottom:5px; max-width: 100%;" allowfullscreen></iframe>'			
		);
		
		// Grab URL data
		private function fetch_url($url)
		{
			// According to Providers API (Navigate to their API instead of website)
			if($this->find_rule($url) == 'soundcloud.com/')
			{
				$url = 'http://soundcloud.com/oembed?format=xml&url='.$url.'&iframe=true';	
			}

			$ch = curl_init();
			$timeout = 2000;
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0)");
			curl_setopt($ch, CURLOPT_ENCODING, '');
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,false);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,false);
			curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
			$data = curl_exec($ch);
			curl_close($ch);
			
			return $data;		
		}
		
		// Find Rule
		private function find_rule($url)
		{
			foreach($this->rules as $key => $rule)
			{
				if(stripos($url, $key))
				{
					return $key; 
				} 
			}
		}
		
		// Extract Embed Codes
		public function extract_embed_code($url, $extract)
		{
			$html = $this->fetch_url($url);
			preg_match_all($extract, $html, $matches);

			return $matches[1][0];
		}
		
		// Format URL
		private function format_url($text, $url_mode='')
		{
			$ntext = '';
			if(stripos($text, '/') == true)
			{
				// from: http://css-tricks.com/snippets/php/find-urls-in-text-make-links/
				$reg_exUrl = '$\b(https?)://[-A-Z0-9+&@#/%?=~_|!:,.;]*[-A-Z0-9+&@#/%=~_|]$i';
				preg_match_all($reg_exUrl, $text, $matches);
				
				$new_matches = array_unique(array_map('trim',$matches[0]));
				
				$usedPatterns = array();
				foreach($new_matches as $pattern)
				{
					if(!array_key_exists($pattern, $usedPatterns))
					{ 
						$usedPatterns[$pattern] = true;
						$pattern2 = substr($pattern, -3); 
						if($pattern2 == "gif" || $pattern2 == "gif" || $pattern2 == "jpg" || $pattern2 == "png") { 
							$ntext = str_replace($pattern, '<p><a href="'.$pattern.'"><img class="img-responsive" src="'.$pattern.'"></a></p>', $text);						
						} else {
							if($url_mode == 'normal' || $url_mode == '' || $url_mode == 'embed')
							{
								$ntext = $pattern;
							} elseif($url_mode == 'to_link') {
								$ntext = str_replace($pattern, '<a href="'.$pattern.'" target="_new">'.$pattern.'</a>', $text);	
							} elseif($url_mode == 'oembed') {
								$ntext = $pattern;
							} else {
								return $text;
							}
						}   
					}
				} 
				return $ntext;
			} else {
				return $ntext;	
			}
		}
		
		// Embed 
		public function oembed($string)
		{
			$url = $this->format_url($string);
			$storedUrls = $url;
			
			if(stripos($url, '/') == true)
			{ 
				$found_rule = $this->find_rule($url); 
				if($found_rule)
				{ 
					$extracted = $this->extract_embed_code($url, $this->providers_regex[$found_rule]);
					$embed_data = html_entity_decode(str_replace('%embedCode%', $extracted, $this->rules[$found_rule]));
					$res = str_ireplace($storedUrls, '<p>'.$embed_data.'</p>', $string);
					return $res;
				} else {
					if(stripos($string, '[/') == true)
					{
						return $string;
					} else {
						return $this->format_url($string, 'to_link');
					}
					
				}
			} else {
				return $string;	
			}
		}
		
		// How to debug?
		// $embed->extract_embed_code('http://www.official.fm/tracks/track-code-here', $embed->providers_regex['official.fm/']);
		// $embed->oembed('check out this song: https://www.soundcloud.com/url-here');
	}
	
	$embed = new EmbedEmbed();
	
	
?>